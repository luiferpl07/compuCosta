import { useNavigate } from "react-router-dom";

import { auth } from "../lib/firebase";
import Container from "./Container";

interface UserType {
  uid: string;
  firstName: string;
  lastName: string;
  email: string;
  avatar?: string;
}

const UserInfo = ({ currentUser }: { currentUser: UserType | null }) => {
  const navigate = useNavigate();

  if (!currentUser) {
    return (
      <Container className="py-5 text-white">
        <p className="text-center text-lg">No hay usuario autenticado</p>
      </Container>
    );
  }

  return (
    <Container className="py-5 text-white">
      <div className="relative isolate overflow-hidden bg-gray-900 px-6 py-24 shadow-2xl sm:rounded-3xl sm:px-16">
        <div className="flex flex-col sm:flex-row items-center gap-5 sm:gap-10">
          <img
            src={
              currentUser.avatar ||
              "https://i.ibb.co/mJRkRRV/png-clipart-profile-logo-computer-icons-user-user-blue-heroes-thumbnail.png"
            }
            alt="userImage"
            className="w-40 h-40 rounded-full border border-gray-700 object-cover p-1"
          />
          <div className="text-start flex-1">
            <h2 className="text-xl font-bold tracking-tight sm:text-4xl">
              Bienvenido{" "}
              <span className="underline underline-offset-2 decoration-[1px] font-medium">
                {currentUser.firstName} {currentUser.lastName || ""}
              </span>
            </h2>
            <p className="text-start mt-3 max-w-3xl text-base leading-6 text-gray-300">
              Correo electrónico: {currentUser.email}
            </p>
          </div>
        </div>
        <div className="mt-10 flex items-center gap-x-5 px-4">
          <button
            onClick={() => navigate("/perfil/editar")}
            className="rounded-md bg-white px-8 py-2.5 text-sm font-semibold text-gray-900 hover:bg-gray-100"
          >
            Editar perfil
          </button>
          <button
            onClick={() => navigate("/perfil/direccion")}
            className="rounded-md bg-white px-8 py-2.5 text-sm font-semibold text-gray-900 hover:bg-gray-100"
          >
            Agregar dirección
          </button>
          <button
            onClick={() => {
              auth.signOut();
              navigate("/"); // Redirigir a la página principal después de cerrar sesión
            }}
            className="rounded-md bg-white px-8 py-2.5 text-sm font-semibold text-gray-900 hover:bg-gray-100"
          >
            Cerrar sesión
          </button>
        </div>
      </div>
    </Container>
  );
};

export default UserInfo;
