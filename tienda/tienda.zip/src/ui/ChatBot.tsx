import React, { useState, useEffect, useRef } from 'react';
import { Send, Bot, User, MessageCircle, Bell } from 'lucide-react';
import { config } from "../../config";
import { io, Socket } from 'socket.io-client';
import { EVENTS, emitClientMessage, setupMessageListener } from "../shared/socketService";

interface Message {
  texto: string;
  esAdmin: boolean;
  creado: Date;
  leido?: boolean;
}

function ChatBot() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [nombreUsuario, setNombreUsuario] = useState('');
  const [isNameSubmitted, setIsNameSubmitted] = useState(false);
  const [idChat, setIdChat] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const socketRef = useRef<Socket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const reconnectInterval = useRef<NodeJS.Timeout | null>(null);

  // Función para conectar el socket
  const connectSocket = () => {
    try {
      console.log("Intentando conectar al servidor WebSocket...");
      
      // Desconectar el socket existente si hay uno
      if (socketRef.current && socketRef.current.connected) {
        socketRef.current.disconnect();
      }
      
      // Crear nueva conexión
      socketRef.current = io(config.baseUrl, {
        path: "/socket.io/",
        transports: ["websocket"], // Mantén solo websocket para mejor rendimiento
        withCredentials: true,
        reconnection: true,
        reconnectionAttempts: 10,
        reconnectionDelay: 1000,
        timeout: 10000, // Reducir timeout
      });

      // Configurar eventos del socket
      if (socketRef.current) {
        // Evento de conexión
        socketRef.current.on('connect', () => {
          console.log("✅ Socket conectado exitosamente: ", socketRef.current?.id);
          setIsConnected(true);
          
          // Limpiar el intervalo de reconexión si existe
          if (reconnectInterval.current) {
            clearInterval(reconnectInterval.current);
            reconnectInterval.current = null;
          }
          
          // Si ya tenemos un ID de chat, unirnos a la sala
          if (idChat) {
            console.log(`Uniendo al chat ${idChat}...`);
            socketRef.current?.emit(EVENTS.JOIN_CHAT, idChat);
          }
          
          // Enviar ping para verificar la conexión
          socketRef.current?.emit("ping");
        });
        
        // Evento de desconexión
        socketRef.current.on('disconnect', (reason) => {
          console.log(`Socket desconectado: ${reason}`);
          setIsConnected(false);
          
          // Configurar un intervalo para intentar reconectar
          if (!reconnectInterval.current) {
            reconnectInterval.current = setInterval(() => {
              console.log("Intentando reconectar...");
              connectSocket();
            }, 5000);
          }
        });
        
        // Evento de error de conexión
        socketRef.current.on('connect_error', (error) => {
          console.error("Error de conexión socket:", error);
          setIsConnected(false);
        });
        
        // Evento de bienvenida
        socketRef.current.on('welcome', (data) => {
          console.log("Bienvenida recibida:", data);
        });
        
        // Evento de confirmación de unión al chat
        socketRef.current.on('chat-joined', (data) => {
          console.log("Unido al chat:", data);
        });
        
        // Evento de pong (respuesta al ping)
        socketRef.current.on('pong', (data) => {
          console.log("Pong recibido:", data);
        });
        
        // Evento de mensaje recibido
        socketRef.current.on(EVENTS.NEW_MESSAGE, (data) => {
          console.log("🔔 NUEVO MENSAJE RECIBIDO:", data);
          
          // Asegurarse de que el mensaje tenga los datos mínimos necesarios
          if (data && typeof data === 'object' && data.texto) {
            const newMessage: Message = {
              texto: data.texto,
              esAdmin: data.esAdmin !== undefined ? Boolean(data.esAdmin) : true,
              creado: new Date(data.creado || Date.now()),
              leido: isOpen
            };
            
            // Usar un enfoque funcional para actualizar el estado
            setMessages(prevMessages => [...prevMessages, newMessage]);
            
            // Incrementar contador solo si el chat está cerrado y es un mensaje del admin
            if (!isOpen && data.esAdmin) {
              setUnreadCount(prev => prev + 1);
            }
          }
        });
        
        // Evento de confirmación de mensaje recibido
        socketRef.current.on('message-received', (data) => {
          console.log("Confirmación de mensaje recibido:", data);
        });
      }
    } catch (error) {
      console.error("Error al inicializar el socket:", error);
      setIsConnected(false);
      
      // Configurar un intervalo para intentar reconectar
      if (!reconnectInterval.current) {
        reconnectInterval.current = setInterval(() => {
          console.log("Intentando reconectar después de error...");
          connectSocket();
        }, 5000);
      }
    }
  };

  

  // Inicializar WebSocket al cargar el componente
  useEffect(() => {
    // Comprobar si hay un ID de chat en el almacenamiento local
    const storedChatId = localStorage.getItem('idChat');
    if (storedChatId) {
      setIdChat(storedChatId);
    }
    
    // Comprobar si hay un nombre de usuario en el almacenamiento local
    const storedUserName = localStorage.getItem('chatUserName');
    if (storedUserName) {
      setNombreUsuario(storedUserName);
      setIsNameSubmitted(true);
    }

    // Conectar el socket
    connectSocket();
    
    // Configurar un intervalo para verificar la conexión periódicamente
    const pingInterval = setInterval(() => {
      if (socketRef.current && socketRef.current.connected) {
        socketRef.current.emit("ping");
      }
    }, 30000);
    
    // Limpiar al desmontar
    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
      
      // Limpiar intervalos
      if (reconnectInterval.current) {
        clearInterval(reconnectInterval.current);
      }
      clearInterval(pingInterval);
    };
  }, []);
  
  // Efecto para unirse a la sala de chat cuando cambia el ID
  useEffect(() => {
    if (idChat && socketRef.current && socketRef.current.connected) {
      console.log(`Uniendo al chat ${idChat}...`);
      socketRef.current.emit(EVENTS.JOIN_CHAT, idChat);
    }
  }, [idChat, isConnected]);

  // Auto-scroll al último mensaje
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Cargar mensajes anteriores si hay un chatId
  useEffect(() => {
    if (idChat) {
      fetchPreviousMessages();
    }
  }, [idChat]);

  // Inicializar con mensaje de bienvenida cuando se abre el chat
  useEffect(() => {
    if (isOpen && !isNameSubmitted) {
      console.log("Estableciendo mensaje de bienvenida");
      setMessages([
        {
          texto: "¡Hola! Para poder ayudarte mejor, ¿podrías decirme tu nombre?",
          esAdmin: true,
          creado: new Date(),
          leido: true
        }
      ]);
    }
  }, [isOpen, isNameSubmitted]);
  
  // Actualizar contador de mensajes no leídos
  useEffect(() => {
    const newUnreadCount = messages.filter(m => m.esAdmin && !m.leido).length;
    setUnreadCount(newUnreadCount);
  }, [messages]);

  const fetchPreviousMessages = async () => {
    if (!idChat) {
      console.error("❌ No hay chatId seleccionado");
      return;
    }
  
    try {
      console.log(`Obteniendo mensajes anteriores para el chat ${idChat}...`);
      const response = await fetch(`${config?.baseUrl}${config?.apiPrefix}/chat?idChat=${idChat}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
  
      const data = await response.json();
      console.log("✅ Mensajes obtenidos del backend:", data);
  
      if (!response.ok) {
        throw new Error(data.message || "Error al obtener los mensajes");
      }
  
      setMessages(data);
    } catch (error) {
      console.error("❌ Error al obtener los mensajes:", error);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
  
    console.log("Enviando mensaje:", inputText);
    
    const userMessage: Message = {
      texto: inputText,
      esAdmin: false,
      creado: new Date(),
      leido: true
    };
  
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    // Si el nombre aún no ha sido enviado, guardarlo
    if (!isNameSubmitted) {
      setNombreUsuario(inputText);
      setIsNameSubmitted(true);
      localStorage.setItem('chatUserName', inputText);
      
      // Agregar mensaje de confirmación del bot
      setTimeout(() => {
        const botResponse: Message = {
          texto: `¡Gracias ${inputText}! ¿En qué puedo ayudarte hoy?`,
          esAdmin: true,
          creado: new Date(),
          leido: true
        };
        setMessages(prev => [...prev, botResponse]);
      }, 500);
      
      setInputText('');
      return;
    }
    
    setInputText('');
    
    try {
      console.log("Enviando al servidor:", {
        texto: inputText,
        nombreUsuario: nombreUsuario,
        idChat: idChat
      });
      
      // Enviar mensaje al servidor incluyendo el nombre del usuario
      const response = await fetch(`${config?.baseUrl}${config?.apiPrefix}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          texto: inputText,
          nombreUsuario: nombreUsuario,
          idChat: idChat
        })
      });
  
      const data = await response.json();
      
      // Si es un nuevo chat, guardar el chatId
      if (data.idChat && !idChat) {
        setIdChat(data.idChat);
        localStorage.setItem('idChat', data.idChat);
        
        // Unirse a la sala de chat - verificar si el socket existe
        if (socketRef.current) {
          try {
            socketRef.current.emit(EVENTS.JOIN_CHAT, data.idChat);
          } catch (socketError) {
            console.error("Error al enviar evento JOIN_CHAT:", socketError);
          }
        } else {
          console.warn("Socket no disponible para unirse al chat");
        }
      }
  
      // Enviar mensaje a través de WebSocket - verificar si el socket existe
      if (socketRef.current && (idChat || data.idChat)) {
        try {
          emitClientMessage(socketRef.current, idChat || data.idChat, inputText, nombreUsuario);
        } catch (socketError) {
          console.error("Error al emitir mensaje del cliente:", socketError);
        }
      } else {
        console.warn("Socket no disponible para enviar mensaje");
      }
  
      // Ya no agregamos la respuesta automática del bot
      
    } catch (error) {
      console.error('Error al enviar mensaje:', error);
      
      // Mensaje de error en caso de fallo
      const errorMessage: Message = {
        texto: "Lo siento, ha ocurrido un error al enviar tu mensaje. Por favor, inténtalo de nuevo más tarde.",
        esAdmin: true,
        creado: new Date(),
        leido: true
      };
      
      setMessages(prev => [...prev, errorMessage]);
    }
  };
  const handleOpen = () => {
    setIsOpen(true);
    setMessages(prev => prev.map(msg => ({ ...msg, leido: true })));
    setUnreadCount(0);
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-4 right-4 flex flex-col items-end gap-2 z-50">
        {unreadCount > 0 && (
          <div className="bg-red-600 text-white rounded-full px-2 py-1 text-sm flex items-center gap-1">
            <Bell className="w-4 h-4" />
            {unreadCount} nuevo{unreadCount !== 1 ? 's' : ''}
          </div>
        )}
        <button
          onClick={handleOpen}
          className="bg-red-600 text-white p-4 rounded-full shadow-lg hover:bg-red-700 transition-all transform hover:scale-110"
        >
          <MessageCircle className="w-6 h-6" />
        </button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="w-full max-w-2xl bg-white rounded-lg shadow-lg overflow-hidden relative">
        <button
          onClick={() => setIsOpen(false)}
          className="absolute top-4 right-4 text-white hover:text-red-200 transition-colors"
        >
          ✕
        </button>

        <div className="bg-red-600 p-4 text-white flex items-center gap-2">
          <Bot className="w-6 h-6" />
          <h1 className="text-xl font-semibold">ChatBot de Atención al Cliente</h1>
        </div>

        <div className="h-[500px] overflow-y-auto p-4 space-y-4">
          {messages.map((message, index) => (
            <div key={index} className={`flex ${message.esAdmin ? 'justify-start' : 'justify-end'}`}>
              <div className={`flex items-start gap-2 max-w-[80%] ${message.esAdmin ? 'flex-row' : 'flex-row-reverse'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${message.esAdmin ? 'bg-red-100' : 'bg-green-100'}`}>
                  {message.esAdmin ? <Bot className="w-5 h-5 text-red-600" /> : <User className="w-5 h-5 text-green-600" />}
                </div>
                <div className={`rounded-lg p-3 ${message.esAdmin ? 'bg-red-100 text-red-900' : 'bg-green-100 text-green-900'}`}>
                  <p className="text-sm">{message.texto}</p>
                  <p className="text-xs mt-1 opacity-50">{new Date(message.creado).toLocaleTimeString()}</p>
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <form onSubmit={handleSendMessage} className="p-4 border-t">
          <div className="flex gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={isNameSubmitted ? "Escribe tu mensaje..." : "Escribe tu nombre..."}
              className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
            />
            <button
              type="submit"
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2"
            >
              <Send className="w-5 h-5" />
              <span>Enviar</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ChatBot;