import { useEffect, useState, useDeferredValue, useCallback } from "react";
import { debounce } from "lodash";
import { logo } from "../assets";
import { IoClose, IoSearchOutline, IoMenu } from "react-icons/io5";
import { FiShoppingCart, FiStar, FiUser } from "react-icons/fi";
import Container from "./Container";
import { FaChevronDown } from "react-icons/fa";
import { Link } from "react-router-dom";
import { config } from "../../config";
import { getData } from "../lib";
import { Menu, MenuButton, MenuItem, MenuItems, Transition } from "@headlessui/react";
import { CategoryProps, Product } from "../../type";
import ProductCard from "./ProductCard";
import { store } from "../lib/store";

const bottomNavigation = [
  { title: "INICIO", link: "/" },
  { title: "PRODUCTOS", link: "/productos" },
  { title: "PEDIDOS", link: "/pedidos" },
  { title: "SERVICIOS", link: "/Servicio"},
  { title: "ACERCA DE NOSOTROS", link: "/Acerca De Nosotros"}
];

// Número de categorías a mostrar antes de "Ver todas"
const CATEGORIES_TO_SHOW = 8;

const Header = () => {
  const [searchText, setSearchText] = useState("");
  const [categories, setCategories] = useState<CategoryProps[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const deferredSearch = useDeferredValue(searchText);
  const { cartProduct, favoriteProduct, currentUser } = store();

  // 🔥 1️⃣ Cargar categorías y productos desde la API
  useEffect(() => {
    const fetchData = async () => {
      try {
        const categoryData = await getData(`${config?.baseUrl}${config?.apiPrefix}/categories`);
        setCategories(categoryData);

        const productData = await getData(`${config?.baseUrl}${config?.apiPrefix}/products`);
        setProducts(productData);
      } catch (error) {
        console.error("Error al obtener datos", error);
      }
    };
    fetchData();
  }, []);

  // 🔥 2️⃣ `debounce` optimizado con `useCallback`
  const filterProducts = useCallback(
    debounce((query: string) => {
      if (!query.trim()) {
        setFilteredProducts([]);
        return;
      }

      if ("requestIdleCallback" in window) {
        requestIdleCallback(() => {
          const result = products.filter(
            (item) =>
              item.nombreproducto.toLowerCase().includes(query.toLowerCase()) ||
              item.descripcion?.toLowerCase().includes(query.toLowerCase())
          );
          setFilteredProducts(result);
        });
      } else {
        const result = products.filter(
          (item) =>
            item.nombreproducto.toLowerCase().includes(query.toLowerCase()) ||
            item.descripcion?.toLowerCase().includes(query.toLowerCase())
        );
        setFilteredProducts(result);
      }
    }, 150), // 🔥 Responde más rápido sin bloquear la UI
    [products]
  );

  // 🔥 3️⃣ Ejecutar el filtro cuando `deferredSearch` cambie
  useEffect(() => {
    filterProducts(deferredSearch);
  }, [deferredSearch, filterProducts]);

  // Toggle para el menú móvil
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
    // Cerrar búsqueda si está abierta
    if (mobileSearchOpen) setMobileSearchOpen(false);
  };

  // Toggle para la búsqueda móvil
  const toggleMobileSearch = () => {
    setMobileSearchOpen(!mobileSearchOpen);
    // Cerrar menú si está abierto
    if (mobileMenuOpen) setMobileMenuOpen(false);
  };

  return (
    <div className="w-full bg-textoBlanco md:sticky md:top-0 z-50">
      {/* 🔹 Barra superior con logo y búsqueda */}
      <div className="max-w-screen-xl mx-auto min-h-[5rem] flex items-center justify-between px-4 lg:px-0">
        {/* Botón de menú móvil */}
        <button 
          className="md:hidden text-2xl mr-2 flex items-center justify-center" 
          onClick={toggleMobileMenu}
          aria-label="Menu"
        >
          <IoMenu />
        </button>
        
        <Link to={"/"} className="flex-shrink-0">
          <img src={logo} alt="Logo" className="w-28 md:w-44" />
        </Link>

        {/* 🔍 Barra de búsqueda (escritorio) */}
        <div className="hidden md:inline-flex max-w-3xl w-full relative">
          <input
            type="text"
            onChange={(e) => setSearchText(e.target.value)}
            value={searchText}
            placeholder="Buscar Productos..."
            className="w-full flex-1 rounded-full text-gray-900 text-lg placeholder:text-base 
              placeholder:tracking-wide shadow-sm ring-1 ring-inset
              ring-gray-300 placeholder:text-gray-400 placeholder:font-normal focus:ring-1
              focus:ring-textoNegro sm:text-sm px-4 py-2"
          />
          {searchText ? (
            <IoClose
              onClick={() => setSearchText("")}
              className="absolute top-2.5 right-4 text-xl hover:text-red-500 cursor-pointer duration-200"
            />
          ) : (
            <IoSearchOutline className="absolute top-2.5 right-4 text-xl" />
          )}
        </div>

        {/* 🔍 Botón de búsqueda (móvil) */}
        <button 
          className="md:hidden text-2xl mr-2" 
          onClick={toggleMobileSearch}
          aria-label="Buscar"
        >
          <IoSearchOutline />
        </button>

        {/* 🔹 Menú de usuario y carrito */}
        <div className="flex items-center gap-x-3 md:gap-x-6 text-xl md:text-2xl">
          <Link to={"/perfil"}>
            {currentUser ? (
              <img
                src={currentUser?.avatar}
                alt="profileImg"
                className="w-8 h-8 md:w-10 md:h-10 rounded-full object-cover"
              />
            ) : (
              <FiUser className="hover:text-skyText duration-200 cursor-pointer" />
            )}
          </Link>

          <Link to={"/favorito"} className="relative block">
            <FiStar className="hover:text-textoRojo duration-200 cursor-pointer" />
            <span className="inline-flex items-center justify-center bg-textoAmarillo
              text-whiteText absolute -top-1 -right-2 text-[9px] rounded-full w-4 h-4">
              {favoriteProduct?.length > 0 ? favoriteProduct.length : "0"}
            </span>
          </Link>

          <Link to={"/carrito"} className="relative block">
            <FiShoppingCart className="hover:text-textoRojo duration-200 cursor-pointer" />
            <span className="inline-flex items-center justify-center bg-textoAmarillo
              text-whiteText absolute -top-1 -right-2 text-[9px] rounded-full w-4 h-4">
              {cartProduct?.length > 0 ? cartProduct.length : "0"}
            </span>
          </Link>
        </div>
      </div>

      {/* 🔍 Barra de búsqueda móvil */}
      {mobileSearchOpen && (
        <div className="md:hidden w-full px-4 pb-3">
          <div className="relative">
            <input
              type="text"
              onChange={(e) => setSearchText(e.target.value)}
              value={searchText}
              placeholder="Buscar Productos..."
              className="w-full flex-1 rounded-full text-gray-900 text-base
                placeholder:tracking-wide shadow-sm ring-1 ring-inset
                ring-gray-300 placeholder:text-gray-400 placeholder:font-normal focus:ring-1
                focus:ring-textoNegro px-4 py-2"
              autoFocus
            />
            {searchText ? (
              <IoClose
                onClick={() => setSearchText("")}
                className="absolute top-2.5 right-4 text-xl hover:text-red-500 cursor-pointer duration-200"
              />
            ) : (
              <IoSearchOutline className="absolute top-2.5 right-4 text-xl" />
            )}
          </div>
        </div>
      )}

      {/* 🔍 Resultados de búsqueda */}
      {searchText && (
        <div className="absolute left-0 top-20 w-full mx-auto max-h-[80vh] px-4 md:px-10 py-5 bg-white z-20 overflow-y-scroll text-black shadow-lg shadow-skyText scrollbar-hide">
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 md:gap-5">
              {filteredProducts.map((item) => (
                <ProductCard key={item.idproducto} item={item} setSearchText={setSearchText} />
              ))}
            </div>
          ) : (
            <div className="py-6 md:py-10 bg-gray-50 w-full flex items-center justify-center border border-gray-600 rounded-md">
              <p className="text-base md:text-xl font-normal px-4 text-center">
                No hay productos que coincidan con{" "}
                <span className="underline underline-offset-2 decoration-[1px] text-red-500 font-semibold">
                  {`(${searchText})`}
                </span>
                . Por favor, inténtalo de nuevo.
              </p>
            </div>
          )}
        </div>
      )}

      {/* 🔹 Menú de navegación */}
      <div className="w-full bg-textoRojo text-textoBlanco">
        <Container className="py-2 max-w-4xl flex items-center gap-3 md:gap-5 justify-between">
          <Menu>
            <MenuButton className="inline-flex items-center gap-1 md:gap-2 rounded-md border border-gray-50 hover:border-white py-1 md:py-1.5 px-2 md:px-3 text-sm md:text-base font-semibold text-gray-100 hover:text-textoBlanco">
              Categorias <FaChevronDown className="text-sm md:text-base mt-1" />
            </MenuButton>
            <Transition
              enter="transition ease-out duration-75"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="transition ease-in duration-100"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <MenuItems
                anchor="bottom end"
                className="w-48 md:w-52 origin-top-right rounded-xl border border-white bg-red-600 p-1 text-xs/6 md:text-sm/6 text-gray-200 [--anchor-gap:var(--spacing-1)] focus:outline-none hover:text-white z-50"
              >
                {/* Mostrar solo las primeras CATEGORIES_TO_SHOW categorías */}
                {categories.slice(0, CATEGORIES_TO_SHOW).map((item: CategoryProps) => (
                  <MenuItem key={item?.id}>
                    <Link
                      to={`/productos?categoria=${item?.slug}`}
                      className="flex w-full items-center gap-2 rounded-lg py-1.5 md:py-2 px-2 md:px-3 data-[focus]:bg-white/20 tracking-wide"
                    >
                      {item?.nombre}
                    </Link>
                  </MenuItem>
                ))}
                
                {/* Opción "Ver todas" si hay más categorías que el límite */}
                {categories.length > CATEGORIES_TO_SHOW && (
                  <MenuItem>
                    <Link
                      to="/productos"
                      className="flex w-full items-center gap-2 rounded-lg py-1.5 md:py-2 px-2 md:px-3 data-[focus]:bg-white/20 tracking-wide font-medium border-t border-white/20 mt-1"
                    >
                      Ver todas
                    </Link>
                  </MenuItem>
                )}
              </MenuItems>
            </Transition>
          </Menu>
          
          {/* Enlaces de navegación (escritorio) */}
          {bottomNavigation.map(({ title, link }) => (
            <Link 
              to={link}
              key={title} 
              className="uppercase hidden md:inline-flex text-sm 
                font-semibold text-textoBlanco/90 hover:text-textoBlanco duration-200
                relative overflow-hidden group"
            > 
              {title}
              <span className="inline-flex w-full h-[1px] bg-textoBlanco absolute bottom-0 left-0 transform -translate-x-[105%] group-hover:translate-x-0 duration-300" />
            </Link>
          ))}
        </Container>
      </div>

      {/* 🔹 Menú móvil */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute z-50 top-20 left-0 right-0 bg-textoRojo text-textoBlanco shadow-lg">
          <div className="flex flex-col p-4">
            {bottomNavigation.map(({ title, link }) => (
              <Link
                key={title}
                to={link}
                className="py-3 uppercase font-semibold border-b border-white/20 last:border-0"
                onClick={() => setMobileMenuOpen(false)}
              >
                {title}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Header;