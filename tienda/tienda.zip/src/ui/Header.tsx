import { useEffect, useState, useDeferredValue, useCallback, useRef } from "react";
import { debounce } from "lodash";
import { logo } from "../assets";
import { IoClose, IoMenu, IoGridOutline } from "react-icons/io5";
import { FiShoppingCart, FiStar, FiUser } from "react-icons/fi";
import { BiSearchAlt2 } from "react-icons/bi";
import { HiOutlineSparkles, HiOutlineTag } from "react-icons/hi";
import Container from "./Container";
import { FaChevronDown, FaChevronRight } from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";
import { config } from "../../config";
import { getData } from "../lib";
import { CategoryProps, Product } from "../../type";
import ProductCard from "./ProductCard";
import { store } from "../lib/store";

const bottomNavigation = [
  { title: "INICIO", link: "/", icon: <HiOutlineSparkles className="w-4 h-4" /> },
  { title: "SERVICIOS", link: "/Servicio", icon: <HiOutlineTag className="w-4 h-4" />},
  { title: "ACERCA DE NOSOTROS", link: "/acerca-de-nosotros", icon: <FiUser className="w-4 h-4" />},
  { title: "CONTACTO", link: "/Contacto", icon: <IoGridOutline className="w-4 h-4" />}
];

interface CategoryWithSubcategories extends CategoryProps {
  subcategorias?: CategoryProps[];
}

const Header = () => {
  const [searchText, setSearchText] = useState("");
  const [categories, setCategories] = useState<CategoryWithSubcategories[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [showProductsMenu, setShowProductsMenu] = useState(false);
  const [showMobileCategories, setShowMobileCategories] = useState(false);
  const deferredSearch = useDeferredValue(searchText);
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const searchIndexRef = useRef<{[key: string]: Product[]}>({});
  const [subcategoriesMap, setSubcategoriesMap] = useState<{ [key: number]: CategoryProps[] }>({});
  const [activeCategory, setActiveCategory] = useState<number | null>(null);
  const navigate = useNavigate();
  
  const { cartProduct, favoriteProduct, currentUser } = store();

  const organizeCategoriesFromAPI = (categoryData: CategoryProps[]): CategoryWithSubcategories[] => {
    console.log('📊 Organizando categorías desde API:', categoryData.length);
    
    const categoriasActivas = categoryData.filter((cat: CategoryProps) => cat.activo === true);
    console.log('✅ Categorías activas:', categoriasActivas.length);
    
    const parentCategories = categoriasActivas.filter((cat: CategoryProps) => cat.padre_id === null);
    const childCategories = categoriasActivas.filter((cat: CategoryProps) => cat.padre_id !== null);
    
    console.log('👨‍👩‍👧‍👦 Categorías padre:', parentCategories.length);
    console.log('👶 Categorías hijas:', childCategories.length);

    const subcategoriesGrouped: { [key: number]: CategoryProps[] } = {};
    childCategories.forEach((sub: CategoryProps) => {
      const padreActivo = parentCategories.find((padre: CategoryProps) => padre.id === sub.padre_id);
      if (padreActivo && sub.padre_id) {
        if (!subcategoriesGrouped[sub.padre_id]) {
          subcategoriesGrouped[sub.padre_id] = [];
        }
        subcategoriesGrouped[sub.padre_id].push(sub);
      }
    });

    console.log('🗂️ Mapa de subcategorías:', subcategoriesGrouped);

    const categoriesWithSubcategories: CategoryWithSubcategories[] = parentCategories.map((parent: CategoryProps) => {
      const subcategorias = subcategoriesGrouped[parent.id] || [];
      return {
        ...parent,
        subcategorias: subcategorias.length > 0 ? subcategorias : undefined
      };
    });
    
    console.log('🏗️ Categorías organizadas:', categoriesWithSubcategories);
    return categoriesWithSubcategories;
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        console.log('🔄 Cargando datos del Header...');
        
        const categoryData: CategoryProps[] = await getData(`${config?.baseUrl}${config?.apiPrefix}/categories`);
        console.log('📥 Categorías recibidas:', categoryData);

        const organizedCategories = organizeCategoriesFromAPI(categoryData);
        
        const subcategoriesGrouped: { [key: number]: CategoryProps[] } = {};
        organizedCategories.forEach((parent: CategoryWithSubcategories) => {
          if (parent.subcategorias && parent.subcategorias.length > 0) {
            subcategoriesGrouped[parent.id] = parent.subcategorias;
          }
        });

        setCategories(organizedCategories);
        setSubcategoriesMap(subcategoriesGrouped);

        // ✅ CARGAR PRODUCTOS Y RESEÑAS EN PARALELO
        const [productData, allReviewsData] = await Promise.all([
          getData(`${config?.baseUrl}${config?.apiPrefix}/products`),
          fetch(`${config?.baseUrl}${config?.apiPrefix}/reviews`, { 
            cache: 'no-store' 
          }).then(res => res.json())
        ]);
        
        console.log('📦 Header - Datos cargados:', {
          totalProductos: productData.length,
          totalReseñas: allReviewsData.length
        });
        
        // ✅ FILTRAR: Solo productos activos Y con stock (cantidad > 0)
        const productosConStock = productData.filter((product: Product) => {
          const tieneStock = (product.cantidad || 0) > 0;
          const estaActivo = product.activo === true;
          
          if (!tieneStock || !estaActivo) {
            console.log(`❌ Header EXCLUIDO de búsqueda: ${product.nombreproducto} - Stock: ${product.cantidad} - Activo: ${product.activo}`);
          }
          
          return estaActivo && tieneStock;
        });
        
        console.log('✅ Header productos CON stock para búsqueda:', productosConStock.length);
        console.log('❌ Header productos SIN stock o inactivos:', productData.length - productosConStock.length);
        
        // ✅ CALCULAR RESEÑAS PARA CADA PRODUCTO
        const enhancedProducts = productosConStock.map((product: Product) => {
          const productReviews = Array.isArray(allReviewsData) 
            ? allReviewsData.filter((review: any) => 
                Number(review.id_producto) === Number(product.idproducto)
              )
            : [];
          
          const reviewCount = productReviews.length;
          const averageRating = reviewCount > 0
            ? productReviews.reduce((acc: number, rev: any) => acc + rev.calificacion, 0) / reviewCount
            : 0;
          
          return {
            ...product,
            enStock: true, // Todos tienen stock porque ya filtramos
            reseñasCount: reviewCount,
            puntuacionPromedio: averageRating,
            reviews: productReviews.map((rev: any) => ({ calificacion: rev.calificacion })),
            marca: product.marca || "Sin marca",
            categorias: product.categorias || "Sin categoría",
            imagenes: product.imagenes || [{ url: `/images/products/${product.slug}.jpg` }]
          };
        });
        
        setProducts(enhancedProducts);

        // ✅ CREAR ÍNDICE DE BÚSQUEDA SOLO CON PRODUCTOS CON STOCK
        const index: { [key: string]: Product[] } = {};
        enhancedProducts.forEach((product: Product) => {
          const words = product.nombreproducto.toLowerCase().split(/\s+/);
          words.forEach(word => {
            if (word.length > 2) {
              if (!index[word]) index[word] = [];
              if (!index[word].some(p => p.idproducto === product.idproducto)) {
                index[word].push(product);
              }
            }
          });
          
          if (product.descripcion) {
            const descWords = product.descripcion.toLowerCase().split(/\s+/);
            descWords.forEach(word => {
              if (word.length > 2) {
                if (!index[word]) index[word] = [];
                if (!index[word].some(p => p.idproducto === product.idproducto)) {
                  index[word].push(product);
                }
              }
            });
          }
        });
        searchIndexRef.current = index;

        console.log('✅ Datos del Header cargados correctamente');
        console.log('🔍 Índice de búsqueda creado con', Object.keys(index).length, 'términos');

      } catch (error) {
        console.error("❌ Error al obtener datos del Header:", error);
      }
    };

    fetchData();
  }, []);

  const filterProducts = useCallback(
    debounce((query: string) => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }

      if (!query.trim()) {
        setFilteredProducts([]);
        setIsSearching(false);
        return;
      }

      setIsSearching(true);

      searchTimeoutRef.current = setTimeout(() => {
        try {
          const searchTerms = query.toLowerCase().split(/\s+/).filter(term => term.length > 1);

          if (Object.keys(searchIndexRef.current).length > 0) {
            const results: Product[] = [];
            const matchedProducts = new Set<number | string>();

            searchTerms.forEach(term => {
              Object.keys(searchIndexRef.current).forEach(indexTerm => {
                if (indexTerm.includes(term)) {
                  searchIndexRef.current[indexTerm].forEach(product => {
                    if (!matchedProducts.has(product.idproducto)) {
                      results.push(product);
                      matchedProducts.add(product.idproducto);
                    }
                  });
                }
              });
            });

            results.sort((a, b) => {
              const aMatchCount = searchTerms.filter(term =>
                a.nombreproducto.toLowerCase().includes(term) ||
                (a.descripcion && a.descripcion.toLowerCase().includes(term))
              ).length;

              const bMatchCount = searchTerms.filter(term =>
                b.nombreproducto.toLowerCase().includes(term) ||
                (b.descripcion && b.descripcion.toLowerCase().includes(term))
              ).length;

              return bMatchCount - aMatchCount;
            });

            setFilteredProducts(results.slice(0, 10));
          } else {
            const result = products
              .filter((item: Product) => {
                const nameLower = item.nombreproducto.toLowerCase();
                const descLower = item.descripcion?.toLowerCase() || '';
                return searchTerms.some(term =>
                  nameLower.includes(term) || descLower.includes(term)
                );
              })
              .slice(0, 10);

            setFilteredProducts(result);
          }
        } catch (error) {
          console.error("❌ Error en búsqueda:", error);
          const queryLower = query.toLowerCase();
          const result = products
            .filter((item: Product) =>
              item.nombreproducto.toLowerCase().includes(queryLower) ||
              (item.descripcion && item.descripcion.toLowerCase().includes(queryLower))
            )
            .slice(0, 10);

          setFilteredProducts(result);
        } finally {
          setIsSearching(false);
        }
      }, 250);

      return () => {
        if (searchTimeoutRef.current) {
          clearTimeout(searchTimeoutRef.current);
        }
      };
    }, 300),
    [products]
  );

  useEffect(() => {
    const cleanup = filterProducts(deferredSearch);
    return cleanup;
  }, [deferredSearch, filterProducts]);

  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleMouseEnter = () => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
    }
    setShowProductsMenu(true);
  };

  const handleMouseLeave = () => {
    hoverTimeoutRef.current = setTimeout(() => {
      setShowProductsMenu(false);
      setActiveCategory(null);
    }, 300);
  };

  useEffect(() => {
    return () => {
      if (hoverTimeoutRef.current) {
        clearTimeout(hoverTimeoutRef.current);
      }
    };
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
    if (mobileSearchOpen) setMobileSearchOpen(false);
  };

  const toggleMobileSearch = () => {
    setMobileSearchOpen(!mobileSearchOpen);
    if (mobileMenuOpen) setMobileMenuOpen(false);
  };

  const clearSearch = () => {
    setSearchText("");
    setFilteredProducts([]);
    setSearchFocused(false);
  };

  const handleProductClick = (productId: number) => {
    clearSearch();
    setMobileSearchOpen(false);
    navigate(`/producto/${productId}`);
  };

  // ✅ FUNCIÓN CORREGIDA: Navegación de categorías
  const handleCategoryNavigation = (categorySlug: string) => {
    console.log('🧭 Navegando a categoría:', categorySlug);
    
    // Cerrar menús
    setShowProductsMenu(false);
    setMobileMenuOpen(false);
    setActiveCategory(null);
    setShowMobileCategories(false);
    
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
    }

    // ✅ NAVEGACIÓN CORREGIDA: Usar navigate con replace para forzar actualización
    const targetUrl = `/productos?categoria=${encodeURIComponent(categorySlug)}`;
    
    console.log('🔍 Navegando a:', targetUrl);
    
    // Usar navigate con state para forzar actualización
    navigate(targetUrl, { 
      replace: false,
      state: { timestamp: Date.now(), categoria: categorySlug }
    });
  };

  useEffect(() => {
    const handleScroll = () => {
      if (mobileMenuOpen || mobileSearchOpen) {
        setMobileMenuOpen(false);
        setMobileSearchOpen(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [mobileMenuOpen, mobileSearchOpen]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest(".search-container") && !target.closest(".search-results") && searchText) {
        setSearchFocused(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [searchText]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMobileMenuOpen(false);
        setMobileSearchOpen(false);
        setShowProductsMenu(false);
        setSearchFocused(false);
        setActiveCategory(null);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  const organizeCategories = () => {
    const isMobile = window.innerWidth < 768;
    const isTablet = window.innerWidth < 1024;
    const isLargeScreen = window.innerWidth >= 1400;

    let columns = 3;
    if (isMobile) columns = 1;
    else if (isTablet) columns = 2;
    else if (isLargeScreen) columns = 4;

    const categoriesPerColumn = Math.ceil(categories.length / columns);
    const columnsArray = [];

    for (let i = 0; i < columns; i++) {
      const startIndex = i * categoriesPerColumn;
      const endIndex = startIndex + categoriesPerColumn;
      columnsArray.push(categories.slice(startIndex, endIndex));
    }

    return columnsArray;
  };

  const hasActiveCategories = categories.length > 0;

  return (
    <div className="w-full bg-gradient-to-r from-white to-gray-50 sticky top-0 z-50 shadow-sm border-b border-gray-100">
      {/* Barra superior elegante con logo y búsqueda */}
      <div className="max-w-screen-xl mx-auto min-h-[4.5rem] sm:min-h-[5.5rem] flex items-center justify-between px-4 sm:px-6 lg:px-8 py-2">
        {/* Botón de menú móvil */}
        <button
          className="lg:hidden group relative text-2xl sm:text-3xl mr-2 sm:mr-3 flex items-center justify-center
            hover:text-textoRojo transition-all duration-300 p-2 rounded-xl hover:bg-red-50"
          onClick={toggleMobileMenu}
          aria-label="Menu"
        >
          <IoMenu className="group-hover:scale-110 transition-transform duration-200" />
        </button>

        {/* Logo */}
        <Link to={"/"} className="flex-shrink-0 group">
          <img
            src={logo}
            alt="Logo"
            className="w-24 h-auto sm:w-28 md:w-32 lg:w-48 max-h-14 sm:max-h-16 object-contain
              group-hover:scale-105 transition-transform duration-300 filter drop-shadow-sm"
          />
        </Link>

        {/* Barra de búsqueda (escritorio y tablet) */}
        <div className="hidden lg:flex max-w-md xl:max-w-2xl w-full mx-6 relative search-container">
          <div className={`flex items-center w-full relative rounded-2xl bg-white
            border-2 transition-all duration-300 px-4 xl:px-5 py-3 shadow-sm hover:shadow-md
            ${searchFocused || searchText ?
              'border-textoRojo shadow-lg ring-4 ring-red-50' :
              'border-gray-200 hover:border-gray-300'}`}>

            <BiSearchAlt2 className={`text-xl xl:text-2xl mr-3 transition-all duration-300
              ${searchFocused || searchText ? 'text-textoRojo scale-110' : 'text-gray-400'}`} />

            <input
              type="text"
              onChange={(e) => setSearchText(e.target.value)}
              value={searchText}
              onFocus={() => setSearchFocused(true)}
              placeholder="¿Qué estás buscando hoy?"
              className="w-full bg-transparent text-gray-800 text-sm xl:text-base outline-none
                placeholder:text-gray-400 placeholder:font-normal font-medium"
            />

            {searchText && (
              <button
                onClick={clearSearch}
                className="flex items-center justify-center ml-3 p-1.5 rounded-full
                  hover:bg-red-50 transition-all duration-200 group"
                aria-label="Limpiar búsqueda"
              >
                <IoClose className="text-xl xl:text-2xl text-gray-500 group-hover:text-textoRojo
                  group-hover:scale-110 transition-all duration-200" />
              </button>
            )}
          </div>
        </div>

        {/* Botón de búsqueda móvil */}
        <button
          className="lg:hidden group text-2xl sm:text-3xl mr-2 sm:mr-3 hover:text-textoRojo
            transition-all duration-300 p-2 rounded-xl hover:bg-red-50"
          onClick={toggleMobileSearch}
          aria-label="Buscar"
        >
          <BiSearchAlt2 className="group-hover:scale-110 transition-transform duration-200" />
        </button>

        {/* Menú de usuario y carrito */}
        <div className="flex items-center gap-x-3 sm:gap-x-4 md:gap-x-5 lg:gap-x-6 text-xl sm:text-2xl md:text-2xl">
          <Link to={"/perfil"} className="group relative hover:text-textoRojo transition-all duration-300
            p-2 rounded-xl hover:bg-red-50">
            {currentUser ? (
              <img
                src={currentUser?.avatar}
                alt="profileImg"
                className="w-7 h-7 sm:w-9 sm:h-9 md:w-10 md:h-10 rounded-full object-cover
                  ring-2 ring-transparent group-hover:ring-textoRojo group-hover:scale-110
                  transition-all duration-300 shadow-sm"
              />
            ) : (
              <FiUser className="group-hover:scale-110 transition-transform duration-200" />
            )}
          </Link>

          <Link to={"/favorito"} className="group relative hover:text-textoRojo transition-all duration-300
            p-2 rounded-xl hover:bg-red-50">
            <FiStar className="group-hover:scale-110 transition-transform duration-200" />
            <span className="inline-flex items-center justify-center bg-gradient-to-r from-textoAmarillo to-yellow-400
              text-white absolute -top-1 -right-1 text-[9px] sm:text-[10px]
              rounded-full w-4 h-4 sm:w-5 sm:h-5 font-bold shadow-sm ring-2 ring-white
              group-hover:scale-110 transition-transform duration-200">
              {favoriteProduct?.length > 0 ? favoriteProduct.length : "0"}
            </span>
          </Link>

          <Link to={"/carrito"} className="group relative hover:text-textoRojo transition-all duration-300
            p-2 rounded-xl hover:bg-red-50">
            <FiShoppingCart className="group-hover:scale-110 transition-transform duration-200" />
            <span className="inline-flex items-center justify-center bg-gradient-to-r from-textoRojo to-red-600
              text-white absolute -top-1 -right-1 text-[9px] sm:text-[10px]
              rounded-full w-4 h-4 sm:w-5 sm:h-5 font-bold shadow-sm ring-2 ring-white
              group-hover:scale-110 transition-transform duration-200">
              {cartProduct?.length > 0 ? cartProduct.length : "0"}
            </span>
          </Link>
        </div>
      </div>

      {/* Barra de búsqueda móvil */}
      {mobileSearchOpen && (
        <div className="lg:hidden w-full px-4 sm:px-6 pb-4 search-container">
          <div className="flex items-center relative rounded-2xl bg-white
            border-2 border-textoRojo shadow-lg px-4 py-3 ring-4 ring-red-50">

            <BiSearchAlt2 className="text-xl sm:text-2xl mr-3 text-textoRojo" />

            <input
              type="text"
              onChange={(e) => setSearchText(e.target.value)}
              value={searchText}
              placeholder="¿Qué estás buscando hoy?"
              className="w-full bg-transparent text-gray-800 text-sm sm:text-base outline-none
                placeholder:text-gray-400 placeholder:font-normal font-medium"
              autoFocus
            />

            {searchText && (
              <button
                onClick={clearSearch}
                className="flex items-center justify-center p-1.5 rounded-full
                  hover:bg-red-50 transition-colors duration-200"
                aria-label="Limpiar búsqueda"
              >
                <IoClose className="text-xl sm:text-2xl text-gray-500 hover:text-textoRojo" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Resultados de búsqueda */}
      {searchText && (searchFocused || mobileSearchOpen) && (
        <div className="absolute left-0 right-0 top-full w-full max-h-[75vh] sm:max-h-[80vh]
          px-4 sm:px-6 lg:px-8 py-6 bg-white z-30 overflow-y-auto
          text-black shadow-2xl border-t border-gray-200 backdrop-blur-sm search-results">

          {isSearching ? (
            <div className="py-8 sm:py-12 w-full flex flex-col items-center justify-center">
              <div className="relative">
                <div className="w-12 h-12 sm:w-14 sm:h-14 border-4 border-gray-200 rounded-full
                  border-t-textoRojo animate-spin mb-4"></div>
                <div className="absolute inset-0 w-12 h-12 sm:w-14 sm:h-14 border-4 border-transparent
                  rounded-full border-r-red-300 animate-spin animation-delay-150"></div>
              </div>
              <p className="text-lg sm:text-xl text-gray-600 font-medium">Buscando productos...</p>
              <p className="text-sm text-gray-400 mt-1">Encontrando las mejores opciones para ti</p>
            </div>
          ) : filteredProducts.length > 0 ? (
            <>
              <div className="mb-4 sm:mb-6 flex justify-between items-center">
                <div>
                  <h3 className="text-lg sm:text-xl font-bold text-textoRojo flex items-center gap-2">
                    <HiOutlineSparkles className="w-5 h-5" />
                    Resultados ({filteredProducts.length})
                  </h3>
                  {filteredProducts.length === 10 && (
                    <p className="text-sm text-gray-500 mt-1">
                      Mostrando los primeros 10 productos más relevantes
                    </p>
                  )}
                </div>
                <button
                  onClick={clearSearch}
                  className="flex items-center gap-2 text-sm text-gray-500 hover:text-textoRojo
                    bg-gray-100 hover:bg-red-50 px-3 py-2 rounded-lg transition-all duration-200"
                >
                  Cerrar <IoClose className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6
                gap-3 sm:gap-4 lg:gap-5">
                {filteredProducts.map((item: Product) => (
                  <div key={item.idproducto} className="group">
                    <ProductCard 
                      item={item} 
                      setSearchText={setSearchText}
                    />
                  </div>
                ))}
              </div>

              {filteredProducts.length === 10 && (
                <div className="mt-6 text-center">
                  <Link
                    to={`/productos?busqueda=${encodeURIComponent(searchText)}`}
                    onClick={clearSearch}
                    className="inline-flex items-center gap-2 py-3 px-6 bg-gradient-to-r from-textoRojo to-red-600
                      text-white rounded-xl hover:from-red-600 hover:to-red-700
                      transition-all duration-300 font-semibold shadow-lg hover:shadow-xl
                      hover:scale-105 transform"
                  >
                    <FaChevronRight className="w-4 h-4" />
                    Ver más resultados
                  </Link>
                </div>
              )}
            </>
          ) : (
            <div className="py-8 sm:py-12 bg-gradient-to-br from-gray-50 to-red-50 w-full flex flex-col
              items-center justify-center border-2 border-dashed border-gray-200 rounded-2xl">
              <div className="text-4xl sm:text-5xl mb-4 text-gray-300">
                <BiSearchAlt2 />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-gray-700 mb-2">
                No encontramos productos
              </h3>
              <p className="text-base sm:text-lg font-medium px-4 text-center text-gray-600 mb-1">
                No hay productos que coincidan con{" "}
                <span className="font-bold text-textoRojo bg-red-50 px-2 py-1 rounded">
                  "{searchText}"
                </span>
              </p>
              <p className="text-sm text-gray-500 px-4 text-center max-w-md">
                Intenta con otras palabras clave o navega por nuestras categorías para descubrir productos increíbles
              </p>
            </div>
          )}
        </div>
      )}

      {/* Menú de navegación */}
      <div className="w-full bg-gradient-to-r from-textoRojo via-red-600 to-textoRojo text-white shadow-lg">
        <Container className="py-3 max-w-5xl flex items-center gap-3 sm:gap-4 md:gap-6 justify-between">
          {/* Menú de PRODUCTOS - Solo si hay categorías activas */}
          {hasActiveCategories && (
            <div
              className="relative group hidden lg:block"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            >
              <div className="inline-flex items-center gap-2 sm:gap-3 rounded-xl bg-white/10 backdrop-blur-sm
                hover:bg-white/20 py-2 sm:py-2.5 px-3 sm:px-4 text-sm sm:text-base lg:text-lg
                font-bold text-white cursor-pointer transition-all duration-300 border border-white/20
                hover:border-white/40 hover:shadow-lg group-hover:scale-105">
                <IoGridOutline className="w-4 h-4 sm:w-5 sm:h-5" />
                <Link to="/productos" className="flex items-center gap-2">
                  PRODUCTOS
                  <FaChevronDown className={`text-xs sm:text-sm lg:text-base
                    transform transition-all duration-300 group-hover:rotate-180`} />
                </Link>
              </div>

              {/* Mega menú  */}
              {showProductsMenu && (
                <div className="absolute left-0 top-full z-50 hidden lg:block">
                  <div className="w-full h-2 bg-transparent"></div>

                  <div
                    className="bg-white border border-gray-200 rounded-xl shadow-xl
                      min-w-[350px] max-w-[850px] w-[85vw] p-4 backdrop-blur-sm"
                    onMouseEnter={handleMouseEnter}
                    onMouseLeave={handleMouseLeave}
                  >
                    {/* Header */}
                    <div className="mb-4">
                      <div className="flex items-center gap-2 mb-3">
                        <div className="w-8 h-8 bg-gradient-to-r from-textoRojo to-red-600 rounded-lg
                          flex items-center justify-center">
                          <IoGridOutline className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-gray-800">
                            Portafolio de Productos
                          </h3>
                          <p className="text-xs text-gray-500">Descubre nuestra variedad</p>
                        </div>
                      </div>
                      <div className="w-full h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent"></div>
                    </div>

                    {/*  Grid de categorías */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 mb-4">
                      {organizeCategories().map((columnCategories, columnIndex) => (
                        <div key={columnIndex} className="space-y-1">
                          {columnCategories.map((category: CategoryWithSubcategories) => (
                            <div 
                              key={category.id} 
                              className="group relative"
                              onMouseEnter={() => setActiveCategory(category.id)}
                              onMouseLeave={() => setActiveCategory(null)}
                            >
                              <button
                                onClick={() => handleCategoryNavigation(category.slug)}
                                className="group flex items-center gap-2 w-full
                                  py-1.5 px-2.5 
                                  text-sm text-gray-700
                                  hover:bg-gradient-to-r hover:from-red-50 hover:to-red-100 hover:text-textoRojo
                                  rounded-lg transition-all duration-300 font-medium border border-transparent
                                  hover:border-red-200 hover:shadow-sm text-left"
                              >
                                <div className="w-1 h-1 bg-textoRojo rounded-full 
                                  opacity-0 group-hover:opacity-100
                                  transition-all duration-300 group-hover:scale-125 flex-shrink-0"></div>
                                <span className="group-hover:translate-x-0.5 
                                  transition-transform duration-300 truncate text-sm leading-tight">
                                  {category.nombre}
                                </span>
                                {category.subcategorias && category.subcategorias.length > 0 && (
                                  <FaChevronRight className="w-2.5 h-2.5 ml-auto 
                                    opacity-0 group-hover:opacity-100 text-textoRojo 
                                    transition-all duration-300 flex-shrink-0" />
                                )}
                              </button>

                              {/* ✅ Subcategorías CORREGIDAS */}
                              {category.subcategorias && category.subcategorias.length > 0 && activeCategory === category.id && (
                                <div className="absolute left-full top-0 z-50 ml-1 
                                  w-44 sm:w-48 md:w-52
                                  bg-white border border-gray-200 rounded-lg shadow-lg 
                                  p-2 animate-in slide-in-from-left-2 duration-200
                                  max-w-[calc(100vw-2rem)] overflow-hidden">
                                  
                                  <div className="space-y-0.5 max-h-36 sm:max-h-40 overflow-y-auto">
                                    {category.subcategorias.map((subcat: CategoryProps) => (
                                      <button
                                        key={subcat.id}
                                        onClick={() => handleCategoryNavigation(subcat.slug)}
                                        className="flex items-center gap-1.5 w-full
                                          py-1.5 px-2 
                                          text-xs text-gray-700 rounded-md
                                          hover:bg-red-50 hover:text-textoRojo transition-all duration-200
                                          border border-transparent hover:border-red-100 text-left"
                                      >
                                        <div className="w-1 h-1 bg-gray-300 rounded-full 
                                          hover:bg-textoRojo transition-colors duration-200 flex-shrink-0"></div>
                                        <span className="truncate hover:translate-x-0.5 
                                          transition-transform duration-200 leading-tight">
                                          {subcat.nombre}
                                        </span>
                                      </button>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      ))}
                    </div>

                    {/* Botón ver todos */}
                    <div className="pt-4 border-t border-gray-200">
                      <Link
                        to="/productos"
                        className="group inline-flex items-center justify-center w-full py-3 px-4
                          bg-gradient-to-r from-textoRojo to-red-600 text-white rounded-lg
                          hover:from-red-600 hover:to-red-700 transition-all duration-300
                          font-semibold text-sm shadow-lg hover:shadow-xl
                          hover:scale-105 transform"
                        onClick={() => {
                          setShowProductsMenu(false);
                          setActiveCategory(null);
                          if (hoverTimeoutRef.current) {
                            clearTimeout(hoverTimeoutRef.current);
                          }
                        }}
                      >
                        <HiOutlineSparkles className="w-4 h-4 mr-2 group-hover:rotate-12 transition-transform duration-300" />
                        Ver todos los productos
                        <FaChevronRight className="w-3 h-3 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
                      </Link>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Enlaces de navegación (escritorio) */}
          <div className="hidden lg:flex items-center gap-4 xl:gap-6">
            {bottomNavigation.map(({ title, link, icon }) => (
              <Link
                to={link}
                key={title}
                className="group relative uppercase text-xs xl:text-sm font-bold text-white/90
                  hover:text-white transition-all duration-300 py-2 px-3 rounded-lg
                  hover:bg-white/10 flex items-center gap-2 whitespace-nowrap"
              >
                <span className="group-hover:scale-110 transition-transform duration-200">
                  {icon}
                </span>
                {title}
                <span className="absolute bottom-0 left-1/2 w-0 h-0.5 bg-white
                  group-hover:w-full group-hover:left-0 transition-all duration-300" />
              </Link>
            ))}
          </div>

          {/* Enlaces de navegación móviles */}
          <div className="flex lg:hidden items-center gap-2 sm:gap-3 overflow-x-auto scrollbar-hide">
            {bottomNavigation.map(({ title, link, icon }) => (
              <Link
                to={link}
                key={title}
                className="group flex items-center gap-1.5 py-1.5 px-2.5 rounded-lg
                  hover:bg-white/10 transition-all duration-300 whitespace-nowrap
                  text-white/90 hover:text-white text-xs font-medium"
              >
                <span className="group-hover:scale-110 transition-transform duration-200 text-xs">
                  {icon}
                </span>
                <span className="hidden sm:inline">{title}</span>
              </Link>
            ))}
          </div>
        </Container>
      </div>

      {/* ✅ Menú móvil CORREGIDO */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
          onClick={() => setMobileMenuOpen(false)}>
          <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-white to-gray-50
            text-gray-800 shadow-2xl max-h-[85vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}>

            {/* Header del menú móvil */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200
              bg-gradient-to-r from-textoRojo to-red-600 text-white">
              <div className="flex items-center gap-3">
                <IoGridOutline className="w-6 h-6" />
                <h2 className="text-xl font-bold">Menú Principal</h2>
              </div>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="text-2xl hover:text-gray-200 transition-colors p-2 rounded-lg hover:bg-white/10"
              >
                <IoClose />
              </button>
            </div>

            <div className="flex flex-col p-6">
              {/* ✅ Menú de productos móvil CORREGIDO */}
              {hasActiveCategories && (
                <div className="bg-gradient-to-r from-red-50 to-red-100 rounded-xl p-4 mb-4 border border-red-200">
                  <button
                    onClick={() => setShowMobileCategories(!showMobileCategories)}
                    className="flex items-center justify-between w-full py-3 uppercase font-bold
                      text-base text-textoRojo hover:text-red-700 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <IoGridOutline className="w-5 h-5" />
                      PRODUCTOS
                    </div>
                    <FaChevronDown className={`transform transition-all duration-300
                      ${showMobileCategories ? 'rotate-180 text-red-700' : ''}`} />
                  </button>

                  {showMobileCategories && (
                    <div className="mt-4 space-y-1.5 max-h-60 overflow-y-auto">
                      <Link
                        to="/productos"
                        className="flex items-center gap-3 py-2.5 px-3 text-sm font-medium text-gray-700
                          hover:text-textoRojo hover:bg-white rounded-lg transition-all duration-200
                          border border-transparent hover:border-red-200"
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        <HiOutlineSparkles className="w-4 h-4" />
                        Ver todos los productos
                      </Link>
                      
                      {/* ✅ CORREGIDO: Categorías con navegación mejorada */}
                      {categories.map((category: CategoryWithSubcategories) => (
                        <button
                          key={category.id}
                          onClick={() => handleCategoryNavigation(category.slug)}
                          className="flex items-center gap-3 py-2.5 px-3 text-sm text-gray-600 w-full text-left
                            hover:text-textoRojo hover:bg-white rounded-lg transition-all duration-200
                            border border-transparent hover:border-red-200"
                        >
                          <div className="w-1.5 h-1.5 bg-textoRojo rounded-full flex-shrink-0"></div>
                          <span className="truncate">{category.nombre}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Resto de enlaces móviles */}
              <div className="space-y-2">
                {bottomNavigation.map(({ title, link, icon }) => (
                  <Link
                    key={title}
                    to={link}
                    className="flex items-center gap-4 py-4 px-4 uppercase font-bold text-sm
                      text-gray-700 hover:text-textoRojo hover:bg-red-50 rounded-xl
                      transition-all duration-300 border border-transparent hover:border-red-200"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <span className="text-textoRojo flex-shrink-0">
                      {icon}
                    </span>
                    <span className="truncate">{title}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Header;