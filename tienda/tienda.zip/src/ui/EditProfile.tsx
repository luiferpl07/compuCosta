import { useState } from "react";

const EditProfile = () => {
  const [profile, setProfile] = useState({
    firstName: "",
    lastName: "",
    email: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProfile({
      ...profile,
      [e.target.name]: e.target.value,
    });
  };

  const handleSave = () => {
    // Aquí puedes implementar la lógica para guardar los cambios
    console.log("Perfil actualizado:", profile);
  };

  return (
    <div className="container mx-auto p-5">
      <h2 className="text-2xl mb-4">Editar Perfil</h2>
      <div className="mb-4">
        <label className="block mb-2">Nombre</label>
        <input
          type="text"
          name="firstName"
          value={profile.firstName}
          onChange={handleChange}
          className="border p-2 w-full"
        />
      </div>
      <div className="mb-4">
        <label className="block mb-2">Apellido</label>
        <input
          type="text"
          name="lastName"
          value={profile.lastName}
          onChange={handleChange}
          className="border p-2 w-full"
        />
      </div>
      <div className="mb-4">
        <label className="block mb-2">Correo Electrónico</label>
        <input
          type="email"
          name="email"
          value={profile.email}
          onChange={handleChange}
          className="border p-2 w-full"
        />
      </div>
      <button onClick={handleSave} className="bg-blue-500 text-white p-2">
        Guardar cambios
      </button>
    </div>
  );
};

export default EditProfile;