import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const AddAddress = () => {
  const navigate = useNavigate();
  const [address, setAddress] = useState({
    street: "",
    city: "",
    zip: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAddress({
      ...address,
      [e.target.name]: e.target.value,
    });
  };

  const handleSaveAddress = () => {
    console.log("Dirección agregada:", address);
    navigate("/");  // Redirigir a la página principal
  };

  return (
    <div className="container mx-auto p-5">
      <h2 className="text-2xl mb-4">Agregar Dirección</h2>
      <input
        type="text"
        name="street"
        placeholder="Calle"
        value={address.street}
        onChange={handleChange}
        className="border p-2 w-full mb-3"
      />
      <input
        type="text"
        name="city"
        placeholder="Ciudad"
        value={address.city}
        onChange={handleChange}
        className="border p-2 w-full mb-3"
      />
      <input
        type="text"
        name="zip"
        placeholder="Código Postal"
        value={address.zip}
        onChange={handleChange}
        className="border p-2 w-full mb-3"
      />
      <button onClick={handleSaveAddress} className="bg-blue-500 text-white p-2">
        Guardar dirección
      </button>
    </div>
  );
};

export default AddAddress;
