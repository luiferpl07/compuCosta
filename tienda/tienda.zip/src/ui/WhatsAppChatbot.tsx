import React, { useState, useEffect, useRef } from "react";

const ChatbotWhatsApp = ({
  numeroWhatsApp = "",
  nombreAgente = "Soporte",
  avatarAgente = "https://via.placeholder.com/40",
  mensajeBienvenida = "¡Hola! Para ayudarte mejor, por favor comparte algunos datos básicos.",
  posicion = "bottom-right",
  colorTema = "#25D366",
  retraso = 2000,
  abrirAutomatico = false,
  apiEndpoint = "/api/chatbot", // API para manejar mensajes
}) => {
  const [abierto, setAbierto] = useState(false);
  const [mensajes, setMensajes] = useState([]);
  const [entradaTexto, setEntradaTexto] = useState("");
  const [escribiendo, setEscribiendo] = useState(false);
  const [etapaActual, setEtapaActual] = useState("bienvenida");
  const [datosUsuario, setDatosUsuario] = useState({ nombre: "", telefono: "", consulta: "" });
  const [idSesion, setIdSesion] = useState("");
  const [conectado, setConectado] = useState(false);
  const refFinalMensajes = useRef(null);
  const intervaloMensajes = useRef(null);

  const posiciones = {
    "bottom-right": "bottom-4 right-4",
    "bottom-left": "bottom-4 left-4",
    "top-right": "top-4 right-4",
    "top-left": "top-4 left-4",
  };

  useEffect(() => {
    if (!idSesion) {
      setIdSesion("chat_" + Date.now() + "_" + Math.random().toString(36).substring(2, 15));
    }
  }, [idSesion]);

  useEffect(() => {
    if (abrirAutomatico) {
      const timer = setTimeout(() => setAbierto(true), retraso);
      return () => clearTimeout(timer);
    }
  }, [abrirAutomatico, retraso]);

  useEffect(() => {
    if (abierto && mensajes.length === 0) {
      setEscribiendo(true);
      setTimeout(() => {
        setMensajes([{ id: 1, texto: mensajeBienvenida, remitente: "agente", timestamp: new Date() }]);
        setEscribiendo(false);
        setTimeout(() => enviarMensajeAgente("¿Cuál es tu nombre?"), 1000);
      }, 500);
    }
  }, [abierto]);

  useEffect(() => {
    if (conectado && idSesion) {
      if (intervaloMensajes.current) clearInterval(intervaloMensajes.current);
      intervaloMensajes.current = setInterval(obtenerMensajesNuevos, 3000);
      return () => clearInterval(intervaloMensajes.current);
    }
  }, [conectado, idSesion]);

  const obtenerMensajesNuevos = async () => {
    try {
      const response = await fetch(`${apiEndpoint}/mensajes?sessionId=${idSesion}`);
      if (response.ok) {
        const data = await response.json();
        if (data.mensajes?.length) {
          setMensajes(prev => [...prev, ...data.mensajes]);
        }
      }
    } catch (error) {
      console.error("Error al obtener mensajes:", error);
    }
  };

  const enviarMensajeAgente = (texto) => {
    setMensajes(prev => [...prev, { id: prev.length + 1, texto, remitente: "agente", timestamp: new Date() }]);
  };

  const manejarEntradaUsuario = async (texto) => {
    setMensajes(prev => [...prev, { id: prev.length + 1, texto, remitente: "usuario", timestamp: new Date() }]);

    if (etapaActual === "bienvenida") {
      setDatosUsuario(prev => ({ ...prev, nombre: texto }));
      enviarMensajeAgente(`Gracias ${texto}. ¿Cuál es tu número de celular?`);
      setEtapaActual("telefono");
    } else if (etapaActual === "telefono") {
      setDatosUsuario(prev => ({ ...prev, telefono: texto }));
      enviarMensajeAgente("¿En qué podemos ayudarte?");
      setEtapaActual("consulta");
    } else if (etapaActual === "consulta") {
      setDatosUsuario(prev => ({ ...prev, consulta: texto }));
      setEscribiendo(true);
      try {
        const response = await fetch(apiEndpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sessionId: idSesion, ...datosUsuario, consulta: texto }),
        });
        if (response.ok) {
          enviarMensajeAgente("Gracias. Un asesor te contactará en breve.");
          setConectado(true);
        }
      } catch (error) {
        enviarMensajeAgente("Error al conectar con soporte. Inténtalo más tarde.");
      }
      setEscribiendo(false);
    }
  };

  return (
    <div className={`fixed ${posiciones[posicion]} z-50`}>
      <button onClick={() => setAbierto(!abierto)} style={{ backgroundColor: colorTema }} className="p-3 rounded-full text-white shadow-lg">
        💬
      </button>
      {abierto && <div className="bg-white p-4 rounded-lg shadow-lg w-80"> {/* Contenedor del chat */} </div>}
    </div>
  );
};

export default ChatbotWhatsApp;
