import { useState, useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import UserInfo from "../ui/UserInfo";
import Container from "../ui/Container";
import Loading from "../ui/Loading";
import Registration from "../ui/Registration";

const Perfil = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser, loading: authLoading, isInitialized } = useAuth();
  
  // Refs para evitar re-renders y hacer el proceso más rápido
  const hasProcessedRedirectRef = useRef(false);
  const redirectProcessingRef = useRef(false);
  
  const [screenSize, setScreenSize] = useState({
    width: typeof window !== "undefined" ? window.innerWidth : 0,
    height: typeof window !== "undefined" ? window.innerHeight : 0
  });

  // Función optimizada para detectar tamaño de pantalla
  const updateScreenSize = () => {
    setScreenSize({
      width: window.innerWidth,
      height: window.innerHeight
    });
  };

  // Manejador de resize optimizado
  useEffect(() => {
    updateScreenSize();
    
    let timeoutId: ReturnType<typeof setTimeout>;
    
    const handleResize = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(updateScreenSize, 100);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      clearTimeout(timeoutId);
    };
  }, []);

  // 🚀 EFECTO DE REDIRECCIÓN ULTRA RÁPIDO - VERSIÓN OPTIMIZADA
  useEffect(() => {
    // Condiciones para redirección instantánea
    if (currentUser && 
        isInitialized && 
        !hasProcessedRedirectRef.current && 
        !redirectProcessingRef.current) {
      
      console.log("⚡ REDIRECCIÓN INSTANTÁNEA iniciando...");
      
      // Marcar como procesando inmediatamente para evitar múltiples ejecuciones
      redirectProcessingRef.current = true;
      hasProcessedRedirectRef.current = true;
      
      // Procesar redirección de forma síncrona
      const searchParams = new URLSearchParams(location.search);
      const redirectTo = searchParams.get('redirect');
      
      if (redirectTo) {
        console.log(`⚡ Redirigiendo instantáneamente a: ${redirectTo}`);
        
        // Usar requestAnimationFrame para redirección más suave
        requestAnimationFrame(() => {
          if (redirectTo === 'carrito') {
            navigate('/carrito', { replace: true });
          } else {
            navigate(decodeURIComponent(redirectTo), { replace: true });
          }
        });
      } else {
        console.log("⚡ Usuario logueado, permaneciendo en perfil");
      }
      
      // Reset processing flag después de un breve delay
      setTimeout(() => {
        redirectProcessingRef.current = false;
      }, 100);
    }
    
    // Reset cuando no hay usuario
    if (!currentUser && hasProcessedRedirectRef.current) {
      hasProcessedRedirectRef.current = false;
      redirectProcessingRef.current = false;
    }
  }, [currentUser, isInitialized, location.search, navigate]);

  // Debug optimizado - Solo en desarrollo
  useEffect(() => {
    if (process.env.NODE_ENV === 'development') {
      console.log("🔍 Perfil Estado:", {
        isInitialized,
        authLoading,
        hasUser: !!currentUser,
        userEmail: currentUser?.email,
        hasProcessedRedirect: hasProcessedRedirectRef.current,
        shouldShowProfile: currentUser && isInitialized && !authLoading
      });
    }
  }, [isInitialized, authLoading, currentUser]);

  // Función optimizada para clases CSS responsivas
  const getResponsiveClasses = () => {
    const width = screenSize.width;
    
    let containerClasses = "w-full mx-auto transition-all duration-300 ";
    let paddingClasses = "px-4 py-4 ";
    let maxWidthClasses = "";
    
    if (width < 640) {
      paddingClasses += "sm:px-4 sm:py-4 ";
      maxWidthClasses = "max-w-full ";
    } else if (width < 768) {
      paddingClasses += "sm:px-6 sm:py-5 ";
      maxWidthClasses = "max-w-lg ";
    } else if (width < 1024) {
      paddingClasses += "md:px-8 md:py-6 ";
      maxWidthClasses = "max-w-xl ";
    } else {
      paddingClasses += "lg:px-10 lg:py-8 ";
      maxWidthClasses = "max-w-4xl ";
    }
    
    return {
      container: containerClasses + maxWidthClasses + paddingClasses,
      authContainer: "bg-white rounded-lg shadow-lg overflow-hidden mt-4 mb-8"
    };
  };

  const classes = getResponsiveClasses();
  
  // 🚀 LÓGICA DE LOADING ULTRA OPTIMIZADA
  // Solo mostrar loading en casos absolutamente necesarios
  const shouldShowLoading = !isInitialized || (authLoading && !currentUser && !redirectProcessingRef.current);
  
  if (shouldShowLoading) {
    return (
      <Container>
        <div className={classes.container}>
          <div className="flex flex-col items-center justify-center py-8">
            <Loading />
            <p className="mt-4 text-gray-600 text-center">
              {!isInitialized ? "Inicializando..." : "Autenticando..."}
            </p>
          </div>
        </div>
      </Container>
    );
  }

  // 🚀 CONDICIÓN ULTRA SIMPLE PARA MOSTRAR EL PERFIL
  const showUserProfile = currentUser && isInitialized;

  return (
    <Container>
      <div className={classes.container}>
        <h1 className="text-2xl md:text-3xl font-bold mb-6 text-red-600">
          {showUserProfile ? 'Mi Perfil' : 'Accede a tu Cuenta'}
        </h1>
        
        {showUserProfile ? (
          <div>            
            <UserInfo currentUser={currentUser} />
          </div>
        ) : (
          <div className={classes.authContainer}>
            <Registration className="w-full" />
          </div>
        )}
      </div>
    </Container>
  );
};

export default Perfil;