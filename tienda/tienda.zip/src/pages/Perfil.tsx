import { useState, useEffect } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "../lib/firebase";

import UserInfo from "../ui/UserInfo";
import Container from "../ui/Container";
import Loading from "../ui/Loading";
import Registration from "../ui/Registration";

// Asegurar que firstName y lastName siempre sean string
export interface UserType {
  uid: string;
  firstName: string;  
  lastName: string;   
  email: string;
  avatar?: string;
  createdAt?: string;
}

const Perfil = () => {
  const [currentUser, setCurrentUser] = useState<UserType | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        const displayNameParts = user.displayName ? user.displayName.split(" ") : ["Usuario"];

        setCurrentUser({
          uid: user.uid,
          email: user.email || "sin-email@example.com",
          firstName: displayNameParts[0], // Siempre será un string
          lastName: displayNameParts.slice(1).join(" ") || "Desconocido", // Nunca será undefined
          avatar: user.photoURL || "",
        });
      } else {
        setCurrentUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return <Loading />;
  }


 
  
  return (
    <Container>
      {currentUser ? (
        <UserInfo currentUser={currentUser} />
      ) : (
        <Registration/>
      )}
    </Container>
  );
};

export default Perfil;
