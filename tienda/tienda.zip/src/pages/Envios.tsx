
const Envios = () => {
  return (
    <div>
      envios
    </div>
  )
}

export default Envios
