const Cancelar = () => {
  return <div>Cancelar</div>;
};

export default Cancelar;
